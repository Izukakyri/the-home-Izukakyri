// KIỂM TRA BẢO MẬT: Nếu chưa đăng nhập, bắt buộc quay lại trang login.html
if (sessionStorage.getItem('isLoggedIn') !== 'true') {
    window.location.href = 'login.html';
} else {
    const username = sessionStorage.getItem('username');
    document.getElementById('userDisplay').innerText = username ? username.toUpperCase() : 'Admin';
}

// Hàm đăng xuất
function logout() {
    sessionStorage.removeItem('isLoggedIn');
    sessionStorage.removeItem('username');
    window.location.href = 'login.html';
}

// Lấy dữ liệu từ LocalStorage nếu có
let employees = JSON.parse(localStorage.getItem('employees')) || [];
let editIndex = -1;

const form = document.getElementById('employeeForm');
const employeeList = document.getElementById('employeeList');
const saveBtn = document.getElementById('saveBtn');

// Hiển thị danh sách khi vừa mở trang
renderTable();

// Lắng nghe sự kiện Submit Form (Thêm hoặc Cập nhật)
form.addEventListener('submit', function(e) {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const department = document.getElementById('department').value;
    const baseSalary = parseFloat(document.getElementById('baseSalary').value) || 0;
    const bonus = parseFloat(document.getElementById('bonus').value) || 0;
    const deduction = parseFloat(document.getElementById('deduction').value) || 0;

    const totalSalary = baseSalary + bonus - deduction;

    const empData = { 
        name, 
        email, 
        department, 
        baseSalary, 
        bonus, 
        deduction, 
        totalSalary 
    };

    if (editIndex === -1) {
        employees.push(empData);
    } else {
        employees[editIndex] = empData;
        editIndex = -1;
        saveBtn.innerText = "Thêm Nhân Viên";
        saveBtn.classList.replace('btn-warning', 'btn-success');
    }

    localStorage.setItem('employees', JSON.stringify(employees));
    renderTable();
    resetForm();
});

function formatCurrency(amount) {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
}

function renderTable() {
    employeeList.innerHTML = '';
    if (employees.length === 0) {
        employeeList.innerHTML = `<tr><td colspan="9" class="text-muted">Chưa có nhân viên nào trong hệ thống.</td></tr>`;
        return;
    }

    employees.forEach((emp, index) => {
        const row = `
            <tr>
                <td>${index + 1}</td>
                <td class="text-start">${emp.name}</td>
                <td class="text-start">${emp.email}</td>
                <td>${emp.department}</td>
                <td class="text-end">${formatCurrency(emp.baseSalary)}</td>
                <td class="text-end text-success">+${formatCurrency(emp.bonus)}</td>
                <td class="text-end text-danger">-${formatCurrency(emp.deduction)}</td>
                <td class="text-end fw-bold text-primary">${formatCurrency(emp.totalSalary)}</td>
                <td>
                    <button class="btn btn-warning btn-sm me-1 mb-1" onclick="editEmployee(${index})">Sửa</button>
                    <button class="btn btn-danger btn-sm mb-1" onclick="deleteEmployee(${index})">Xóa</button>
                </td>
            </tr>
        `;
        employeeList.innerHTML += row;
    });
}

function deleteEmployee(index) {
    if (confirm("Bạn có chắc chắn muốn xóa nhân viên này không?")) {
        employees.splice(index, 1);
        localStorage.setItem('employees', JSON.stringify(employees));
        renderTable();
    }
}

function editEmployee(index) {
    const emp = employees[index];
    document.getElementById('name').value = emp.name;
    document.getElementById('email').value = emp.email;
    document.getElementById('department').value = emp.department;
    document.getElementById('baseSalary').value = emp.baseSalary;
    document.getElementById('bonus').value = emp.bonus;
    document.getElementById('deduction').value = emp.deduction;

    editIndex = index;
    saveBtn.innerText = "Cập Nhật";
    saveBtn.classList.replace('btn-success', 'btn-warning');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resetForm() {
    form.reset();
    document.getElementById('bonus').value = 0;
    document.getElementById('deduction').value = 0;
    editIndex = -1;
    saveBtn.innerText = "Thêm Nhân Viên";
    saveBtn.classList.replace('btn-warning', 'btn-success');
}